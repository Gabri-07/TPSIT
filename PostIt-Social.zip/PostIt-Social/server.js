const express = require('express');
const fs = require('fs');
const path = require('path');
const session = require('express-session');
const multer = require('multer');

const app = express();
const PORT = 3000;

// Impostazioni EJS e middleware
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'secretKey',
  resave: false,
  saveUninitialized: true
}));

// Percorsi dei file JSON
const usersFile = path.join(__dirname, 'users.json');
const postsFile = path.join(__dirname, 'posts.json');

// Funzioni helper per leggere/scrivere JSON
function readJSON(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (err) {
    return [];
  }
}
function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// Config Multer per il caricamento delle immagini
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads/'); // Assicurati che questa cartella esista!
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix);
  }
});
const upload = multer({ storage });

// Middleware di autenticazione
function authMiddleware(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

// --------------------------------------
// HOME: Visualizza tutti i post
// --------------------------------------
app.get('/', (req, res) => {
  const posts = readJSON(postsFile);
  res.render('home', { user: req.session.user, posts });
});

// --------------------------------------
// SIGNUP: Registrazione con dati aggiuntivi
// --------------------------------------
// GET /signup: Mostra la pagina di registrazione
app.get('/signup', (req, res) => {
  // All'apertura della pagina, non c'è nessun errore
  res.render('signup', { error: null });
});

// POST /signup: Registra il nuovo utente
app.post('/signup', (req, res) => {
  const { name, surname, email, birthdate, username, password } = req.body;
  const users = readJSON(usersFile);

  // Calcola l'età
  const birthDateObj = new Date(birthdate);
  const ageDifMs = Date.now() - birthDateObj.getTime();
  const ageDate = new Date(ageDifMs);
  const age = Math.abs(ageDate.getUTCFullYear() - 1970);
  if (age < 14) {
    // Ricarica la pagina di signup con messaggio d'errore
    return res.render('signup', { error: 'Devi avere almeno 14 anni per registrarti.' });
  }

  // Controlla se username esiste già
  if (users.some(u => u.username === username)) {
    return res.render('signup', { error: 'Username già in uso' });
  }

  // Controlla se email esiste già
  if (users.some(u => u.email === email)) {
    return res.render('signup', { error: 'Email già in uso' });
  }

  // Se tutto ok, salva l'utente
  users.push({ name, surname, email, birthdate, username, password, followers: [], following: [] });
  writeJSON(usersFile, users);

  res.redirect('/login');
});


// --------------------------------------
// LOGIN
// --------------------------------------
// GET /login: Mostra la pagina di login
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

// POST /login: Verifica credenziali
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const users = readJSON(usersFile);

  const user = users.find(u => u.username === username && u.password === password);
  if (!user) {
    // Se non esiste, mostri l'errore in rosso
    return res.render('login', { error: 'Username e/o password errate' });
  }

  // Se esiste, salvi la sessione e redirect
  req.session.user = username;
  res.redirect('/');
});

// --------------------------------------
// LOGOUT
// --------------------------------------
app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// --------------------------------------
// CREAZIONE NUOVO POST (con foto opzionale)
// --------------------------------------
app.get('/newpost', authMiddleware, (req, res) => {
  res.render('newpost', { user: req.session.user });
});
app.post('/newpost', authMiddleware, upload.single('image'), (req, res) => {
  const { title, content } = req.body;
  const posts = readJSON(postsFile);
  const newPost = {
    id: Date.now().toString(),
    title,
    content,
    image: req.file ? '/uploads/' + req.file.filename : null,
    date: new Date().toLocaleString(),
    author: req.session.user,
    likes: 0,
    comments: []
  };
  posts.push(newPost);
  writeJSON(postsFile, posts);
  res.redirect('/');
});

// --------------------------------------
// LIKE: Aumenta i mi piace
// --------------------------------------
app.post('/like/:id', authMiddleware, (req, res) => {
  const posts = readJSON(postsFile);
  const post = posts.find(p => p.id === req.params.id);
  if (post) {
    post.likes++;
    writeJSON(postsFile, posts);
  }
  res.redirect('/');
});

// --------------------------------------
// COMMENTO: Aggiungi un commento
// --------------------------------------
app.post('/comment/:id', authMiddleware, (req, res) => {
  const { text } = req.body;
  const posts = readJSON(postsFile);
  const post = posts.find(p => p.id === req.params.id);
  if (post) {
    post.comments.push({ author: req.session.user, text });
    writeJSON(postsFile, posts);
  }
  res.redirect('/');
});

// --------------------------------------
// MODIFICA POST
// --------------------------------------
app.get('/editpost/:id', authMiddleware, (req, res) => {
  const posts = readJSON(postsFile);
  const post = posts.find(p => p.id === req.params.id);
  if (!post || post.author !== req.session.user) return res.redirect('/');
  res.render('editpost', { user: req.session.user, post });
});
app.post('/editpost/:id', authMiddleware, (req, res) => {
  const { content } = req.body;
  const posts = readJSON(postsFile);
  const index = posts.findIndex(p => p.id === req.params.id);
  if (index === -1 || posts[index].author !== req.session.user) return res.redirect('/');
  posts[index].content = content;
  writeJSON(postsFile, posts);
  res.redirect('/');
});

// --------------------------------------
// ELIMINAZIONE POST
// --------------------------------------
app.post('/deletepost/:id', authMiddleware, (req, res) => {
  let posts = readJSON(postsFile);
  const post = posts.find(p => p.id === req.params.id);
  if (!post || post.author !== req.session.user) return res.redirect('/');
  posts = posts.filter(p => p.id !== req.params.id);
  writeJSON(postsFile, posts);
  res.redirect('/');
});

// --------------------------------------
// BARRA DI RICERCA UTENTI
// --------------------------------------
app.get('/search', authMiddleware, (req, res) => {
  const queryParam = req.query.query || ''; 
  console.log('Valore di queryParam ricevuto:', queryParam); // Debug

  const query = queryParam.toLowerCase();
  const users = readJSON(usersFile);

  // Filtra solo utenti validi
  const results = users.filter(u => {
      return (
          (u.username && u.username.toLowerCase().includes(query)) ||
          (u.name && u.name.toLowerCase().includes(query)) ||
          (u.surname && u.surname.toLowerCase().includes(query)) ||
          (u.email && u.email.toLowerCase().includes(query))
      );
  });

  console.log('Utenti trovati:', results); // Debug
  res.render('search', { user: req.session.user, results });
});

// --------------------------------------
// FOLLOW/UNFOLLOW
// --------------------------------------
app.post('/follow/:username', authMiddleware, (req, res) => {
  const users = readJSON(usersFile);
  const currentUser = users.find(u => u.username === req.session.user);
  const targetUser = users.find(u => u.username === req.params.username);
  if (!targetUser || targetUser.username === currentUser.username) return res.redirect('/');
  if (currentUser.following && currentUser.following.includes(targetUser.username)) {
    currentUser.following = currentUser.following.filter(u => u !== targetUser.username);
    targetUser.followers = targetUser.followers.filter(u => u !== currentUser.username);
  } else {
    if (!currentUser.following) currentUser.following = [];
    if (!targetUser.followers) targetUser.followers = [];
    currentUser.following.push(targetUser.username);
    targetUser.followers.push(currentUser.username);
  }
  writeJSON(usersFile, users);
  res.redirect('/profile/' + targetUser.username);
});

// --------------------------------------
// PAGINA PROFILO
// --------------------------------------
app.get('/profile/:username', authMiddleware, (req, res) => {
  const users = readJSON(usersFile);
  const posts = readJSON(postsFile);

  // Trova l'utente di cui stiamo visualizzando il profilo
  const profileUser = users.find(u => u.username === req.params.username);
  if (!profileUser) {
    return res.send('Utente non trovato');
  }

  // Trova i post di questo utente
  const userPosts = posts.filter(p => p.author === profileUser.username);

  // L'utente loggato (per sapere se segue già profileUser)
  const currentUser = users.find(u => u.username === req.session.user);

  // Passiamo i dati necessari alla view
  res.render('profile', {
    user: req.session.user,           // username dell'utente loggato
    profileUser,                      // l'utente del profilo
    userPosts,                        // i post del profilo
    currentUser                       // l'utente loggato completo
  });
});
// --------------------------------------
// visualizzazione post
// --------------------------------------
app.get('/post/:id', authMiddleware, (req, res) => {
  const posts = readJSON(postsFile);
  const post = posts.find(p => p.id === req.params.id);

  if (!post) {
    return res.send('Post non trovato');
  }

  res.render('post', { user: req.session.user, post });
});
// --------------------------------------
// impostazione foto profilo
// --------------------------------------
app.post('/uploadProfilePic', authMiddleware, upload.single('profilePic'), (req, res) => {
  const users = readJSON(usersFile);
  const currentUser = users.find(u => u.username === req.session.user);
  if (!currentUser) return res.redirect('/');
  
  // Aggiorna il campo 'profilePic' con il percorso dell'immagine caricata
  currentUser.profilePic = '/uploads/' + req.file.filename;
  writeJSON(usersFile, users);
  
  // Reindirizza all'area profilo
  res.redirect('/profile/' + currentUser.username);
});






app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
