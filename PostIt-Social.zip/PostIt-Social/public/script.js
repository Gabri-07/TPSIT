document.addEventListener('DOMContentLoaded', () => {
  // (Esempio) Gestione pulsante like via AJAX
  document.querySelectorAll('.like-form').forEach(form => {
    form.addEventListener('submit', async function(e) {
      e.preventDefault();
      const postId = this.action.split('/').pop();
      const heartIcon = this.querySelector('.fa-heart');
      const response = await fetch(`/like/${postId}`, { method: 'POST' });
      if (response.ok) {
        heartIcon.classList.toggle('liked');
      }
    });
  });

  // Mostra il form per cambiare foto profilo al click
  const changeProfileButton = document.getElementById('changeProfileButton');
  const profilePicForm = document.getElementById('profilePicForm');

  if (changeProfileButton && profilePicForm) {
    changeProfileButton.addEventListener('click', () => {
      profilePicForm.style.display = 'block';
    });
  }
});
